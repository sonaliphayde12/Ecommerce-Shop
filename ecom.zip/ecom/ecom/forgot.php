<?php 
session_start();
include 'connection.php';
if (isset($_POST['user_name']) && isset($_POST['user_password']) && isset($_POST['frgt']) && isset($_POST['Cfrgt']))
{
	$username = $_POST['user_name'];
	$password = $_POST['user_password'];
	$for_pass = $_POST['frgt'];
	$cfor_pass = $_POST['Cfrgt'];
    $query = "SELECT * FROM users WHERE username='$username' and ques='$for_pass'";
	$result = mysqli_query($conn,$query) or die(mysqli_error($conn));
	$count = mysqli_num_rows($result);
if($count == 1)
{
	echo"<script> alert('SUCCESSFULLY CHANGED');</script>";	
}
	else{
	echo "<script> alert('YOUR ANSWER INVALID OR USERNAME NOT FOUND');</script>";
}
if($password == $cfor_pass)
{
	
$sql="update users set password = '$password' WHERE username = '$username'";
$result = mysqli_query($conn,$sql) or mysqli_error($conn);
}
  else
  {
	  echo "<script> alert('PASSWORD DOES NOT MATCH!');</script>";
  }
}

?>
<a href="frgt.php"><button>GO BACK</button></a>