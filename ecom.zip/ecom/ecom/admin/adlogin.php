<form action="adlog.php" method="POST">
<h1 align="center">Admin Login</h1>
<div align="center">
<h2>Enter Admin name:</h2>
<input type="text" name="username"/>
<h2>Enter Password:</h2>
<input type="password" name="password"/><br><br>
<input type="submit" value="submit"/>
<input type="submit" value="reset"/>
</div>
</form>