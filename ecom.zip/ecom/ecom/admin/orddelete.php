<!DOCTYPE html>

<html>

    <head>

        <title>DELETE order DATA </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>

    <body>

        <form action="orddel.php" method="post">

           Enter Id To Delete:&nbsp;<input type="number" name="id" required><br><br>

            <input type="submit" name="delete" value="Delete order">

        </form>

    </body>

</html>